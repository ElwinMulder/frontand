function kleur_aanpassen() {
    var HeadingToAdjust = document.getElementById ("bottomtext");
    HeadingToAdjust.style.color = "blue";
}

kleur_aanpassen();

document.getElementById("home").addEventListener("click", function() {
    window.location.href = "abn-amro.html";
});

function login() {
    const form = document.getElementById("loginForm");
    const errorMessage = document.getElementById("error-message");
    
    form.addEventListener("submit", function(event) {
        event.preventDefault(); 
    
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
    
        if (
            (username === "admin" && password === "admin123") ||
            (username === "Elwin0510" && password === "aK62pF9N") ||
            (username === "Onno77" && password === "Welcome123")  
        ) {
            window.location.href = "abn-amro.html"; 
        } else {
            errorMessage.style.display = "block"; 
        }
    });
    }

    
    function dashboard() {
        const accounts = [
            { accountNumber: 'NL12ABN345678901', holder: 'Elwin Mulder', balance: 1523.45, lastTransaction: '01-12-2024' },
        ];

        function loadAccounts() {
            const tableBody = document.querySelector('#accounts-table tbody');
            tableBody.innerHTML = '';

            accounts.forEach(account => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${account.accountNumber}</td>
                    <td>${account.holder}</td>
                    <td>€ ${account.balance.toFixed(2)}</td>
                    <td>${account.lastTransaction}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        function addNewAccount() {
            const holder = document.querySelector('#account-holder').value;
            const balance = parseFloat(document.querySelector('#account-balance').value);

            if (holder && !isNaN(balance)) {
                const newAccount = {
                    accountNumber: 'NL' + Math.floor(Math.random() * 1000000000000000),  
                    holder: holder,
                    balance: balance,
                    lastTransaction: new Date().toLocaleDateString()
                };

                accounts.push(newAccount);
                loadAccounts();
                closeAddAccountForm();
            } else {
                alert('Vul alle velden correct in.');
            }
        }

        function showAddAccountForm() {
            document.querySelector('#add-account-form').style.display = 'block';
        }

        function closeAddAccountForm() {
            document.querySelector('#add-account-form').style.display = 'none';
        }

        window.onload = loadAccounts;

        // Zorg ervoor dat functies beschikbaar zijn in de globale scope
        window.addNewAccount = addNewAccount;
        window.showAddAccountForm = showAddAccountForm;
        window.closeAddAccountForm = closeAddAccountForm;
    }

    dashboard();

    function overschriften(){
        let balances = {
            betaalrekening: 1500, // Saldo voor Betaalrekening
            spaarrekening: 3000,  // Saldo voor Spaarrekening
        };
        
        function transferMoney() {
            const fromAccountSelect = document.getElementById("fromAccount");
            const toAccountSelect = document.getElementById("toAccount");
            const amountInput = document.getElementById("amount").value;
            const messageDiv = document.getElementById("message");
        
            const fromAccount = fromAccountSelect.value; // Waarde van bronrekening
            const toAccount = toAccountSelect.value;     // Waarde van doelrekening
            const amount = parseFloat(amountInput);
        
            // Reset bericht
            showMessage("", ""); // Leeg bericht
        
            // Controleer of de bron- en doelrekening hetzelfde zijn
            if (fromAccount === toAccount) {
                showMessage("Je kunt niet naar dezelfde rekening overschrijven.", "error");
                return;
            }
        
            // Validatie van bedrag
            if (isNaN(amount) || amount <= 0) {
                showMessage("Voer een geldig bedrag in.", "error");
                return;
            }
        
            // Limieten controleren voor specifieke rekeningen
            if (fromAccount === "betaalrekening" && amount > 1500) {
                showMessage("Je kunt niet meer dan €1500 in één keer overschrijven vanaf de betaalrekening.", "error");
                return;
            }
        
            if (fromAccount === "spaarrekening" && amount > 3000) {
                showMessage("Je kunt niet meer dan €3000 in één keer overschrijven vanaf de spaarrekening.", "error");
                return;
            }
        
            // Controleer of er voldoende saldo is op de bronrekening
            if (amount > balances[fromAccount]) {
                showMessage("Onvoldoende saldo op de bronrekening.", "error");
                return;
            }
        
            // Geld overschrijven
            balances[fromAccount] -= amount;
            balances[toAccount] += amount;
        
            // Update dropdowntekst met nieuwe saldi
            updateDropdownText();
        
            // Toon succesbericht
            showMessage(`€${amount.toFixed(2)} is succesvol overgeschreven.`, "success");
        }
        
        // Hulpfunctie om berichten te tonen
        function showMessage(message, type) {
            const messageDiv = document.getElementById("message");
            messageDiv.innerHTML = message;
            messageDiv.className = type; // Klassen: "error" of "success"
        }
        
        // Update dropdown met actuele saldi
        function updateDropdownText() {
            const fromAccountDropdown = document.getElementById("fromAccount");
            fromAccountDropdown.options[0].text = `Betaalrekening (€${balances["betaalrekening"].toFixed(2)})`;
            fromAccountDropdown.options[1].text = `Spaarrekening (€${balances["spaarrekening"].toFixed(2)})`;
        }
        }

        function transactiegeschiedenis(){
            const transacties = [
                { type: 'inkomend', datum: '2024-11-01', bedrag: 150.00 },
                { type: 'uitgaand', datum: '2024-11-03', bedrag: -50.00 },
                { type: 'inkomend', datum: '2024-11-05', bedrag: 200.00 },
                { type: 'uitgaand', datum: '2024-11-10', bedrag: -30.00 }
            ];
            
            // Toon transacties in het DOM
            function toonTransacties(transacties) {
                const container = document.getElementById('transactie-container');
                container.innerHTML = '';
            
                if (transacties.length === 0) {
                    container.innerHTML = '<p>Geen transacties gevonden.</p>';
                    return;
                }
            
                const fragment = document.createDocumentFragment();
            
                transacties.forEach(({ type, datum, bedrag }) => {
                    const transactieDiv = document.createElement('div');
                    transactieDiv.classList.add('transactie');
            
                    transactieDiv.innerHTML = `
                        <p><strong>Type:</strong> ${type}</p>
                        <p><strong>Datum:</strong> ${datum}</p>
                        <p><strong>Bedrag:</strong> €${Math.abs(bedrag).toFixed(2)}</p>
                    `;
                    fragment.appendChild(transactieDiv);
                });
            
                container.appendChild(fragment);
            }
            
            // Filter transacties op basis van type en datum
            function filterTransacties() {
                const typeFilter = document.getElementById('filterType').value;
                const datumFilter = document.getElementById('filterDatum').value;
            
                const gefilterdeTransacties = transacties.filter(t => {
                    const typeMatch = (typeFilter === 'alle') || (t.type === typeFilter);
                    const datumMatch = !datumFilter || (t.datum === datumFilter);
                    return typeMatch && datumMatch;
                });
            
                toonTransacties(gefilterdeTransacties);
            }
            
            // Laad alle transacties bij het starten van de pagina
            window.onload = () => toonTransacties(transacties);
            }

            function beleggingen(){
                let beschikbaarSaldo = 760; // Startsaldo
                        let inBezit = 2; // Aantal eenheden dat je bezit
                        const prijsPerEenheid = 120; // Prijs per eenheid
                
                        document.addEventListener("DOMContentLoaded", () => {
                            const categorieSelect = document.getElementById("categorie");
                            const productSelect = document.getElementById("product");
                
                            const cryptoOptions = `
                                <option value="bitcoin">Bitcoin</option>
                                <option value="ethereum">Ethereum</option>
                                <option value="litecoin">Litecoin</option>
                            `;
                            const aandelenOptions = `
                                <option value="Funko">Funko</option>
                                <option value="Vbucks">Vbucks</option>
                                <option value="Spotify">Spotify</option>
                            `;
                
                            categorieSelect.addEventListener("change", () => {
                                if (categorieSelect.value === "crypto") {
                                    productSelect.innerHTML = cryptoOptions;
                                } else if (categorieSelect.value === "aandelen") {
                                    productSelect.innerHTML = aandelenOptions;
                                }
                            });
                        });
                
                        function kopen() {
                            const bedrag = parseFloat(document.getElementById('bedrag').value);
                            const foutmelding = document.getElementById('foutmelding');
                            const resultaat = document.getElementById('resultaat');
                
                            // Reset foutmelding en resultaat
                            foutmelding.style.display = 'none';
                            resultaat.style.display = 'none';
                
                            if (isNaN(bedrag) || bedrag <= 0) {
                                foutmelding.textContent = 'Voer een geldig bedrag in.';
                                foutmelding.style.display = 'block';
                                return;
                            }
                
                            const maximaalBetaalbaar = Math.floor(beschikbaarSaldo / prijsPerEenheid) * prijsPerEenheid;
                            const bedragTeInvesteren = Math.min(bedrag, maximaalBetaalbaar);
                
                            if (bedragTeInvesteren <= 0) {
                                foutmelding.textContent = 'Je hebt niet genoeg saldo om een eenheid te kopen.';
                                foutmelding.style.display = 'block';
                                return;
                            }
                
                            const teKopenEenheden = Math.floor(bedragTeInvesteren / prijsPerEenheid);
                
                            beschikbaarSaldo -= bedragTeInvesteren;
                            inBezit += teKopenEenheden;
                
                            document.getElementById('saldo').textContent = `Beschikbaar saldo: €${beschikbaarSaldo.toFixed(2)}`;
                            document.getElementById('inBezit').textContent = inBezit;
                            resultaat.textContent = `Je hebt €${bedragTeInvesteren.toFixed(2)} geïnvesteerd en ${teKopenEenheden} eenheden gekocht.`;
                            resultaat.style.display = 'block';
                        }
                
                        function verkopen() {
                            const bedrag = parseFloat(document.getElementById('bedrag').value);
                            const foutmelding = document.getElementById('foutmelding');
                            const resultaat = document.getElementById('resultaat');
                
                            // Reset foutmelding en resultaat
                            foutmelding.style.display = 'none';
                            resultaat.style.display = 'none';
                
                            if (isNaN(bedrag) || bedrag <= 0) {
                                foutmelding.textContent = 'Voer een geldig bedrag in.';
                                foutmelding.style.display = 'block';
                                return;
                            }
                
                            const maximaalVerkoopbaar = inBezit * prijsPerEenheid;
                            const bedragTeVerkopen = Math.min(bedrag, maximaalVerkoopbaar);
                
                            if (bedragTeVerkopen <= 0) {
                                foutmelding.textContent = 'Je hebt niet genoeg eenheden om te verkopen.';
                                foutmelding.style.display = 'block';
                                return;
                            }
                
                            const teVerkopenEenheden = Math.floor(bedragTeVerkopen / prijsPerEenheid);
                
                            beschikbaarSaldo += bedragTeVerkopen;
                            inBezit -= teVerkopenEenheden;
                
                            document.getElementById('saldo').textContent = `Beschikbaar saldo: €${beschikbaarSaldo.toFixed(2)}`;
                            document.getElementById('inBezit').textContent = inBezit;
                            resultaat.textContent = `Je hebt €${bedragTeVerkopen.toFixed(2)} ontvangen en ${teVerkopenEenheden} eenheden verkocht.`;
                            resultaat.style.display = 'block';
                        }
                    }

                    function Cryto_Overzicht() {
                        const cryptoPrices = JSON.parse(localStorage.getItem("cryptoPrices")) || {
                          Bitcoin: 90000,
                          Ethereum: 4800,
                          Litecoin: 250,
                        };
                      
                        // Prijsfluctuaties simuleren
                        function simulatePriceFluctuations() {
                          const lastUpdateTime = parseInt(localStorage.getItem("lastUpdateTime")) || Date.now();
                          const currentTime = Date.now();
                          const elapsedSeconds = (currentTime - lastUpdateTime) / 1000;
                      
                          for (const crypto in cryptoPrices) {
                            const changePerSecond = (Math.random() - 0.5) * 10;
                            cryptoPrices[crypto] += changePerSecond * elapsedSeconds;
                            cryptoPrices[crypto] = Math.max(cryptoPrices[crypto], 1); // Minimum prijs is 1
                          }
                      
                          localStorage.setItem("lastUpdateTime", currentTime);
                          saveData();
                          updateCryptoList();
                        }
                      
                        // Data opslaan in localStorage
                        function saveData() {
                          localStorage.setItem("cryptoPrices", JSON.stringify(cryptoPrices));
                        }
                      
                        // De lijst met crypto's bijwerken in de UI
                        function updateCryptoList() {
                          const cryptoList = document.getElementById("crypto-list");
                          cryptoList.innerHTML = "";
                      
                          for (const [crypto, price] of Object.entries(cryptoPrices)) {
                            const item = document.createElement("div");
                            item.className = "crypto-item";
                            item.innerHTML = `
                              <span>${crypto}: €${price.toFixed(2)} per eenheid</span>
                            `;
                            cryptoList.appendChild(item);
                          }
                        }
                      
                        // Transacties blokkeren
                        function handleTransaction(type) {
                          const messageDiv = document.getElementById("message");
                          messageDiv.textContent = "Transacties zijn niet toegestaan.";
                          updateCryptoList(); // Werk de UI bij
                        }
                      
                        // Willekeurige prijsfluctuaties
                        function fluctuatePrices() {
                          for (const crypto in cryptoPrices) {
                            const randomChange = (Math.random() - 0.5) * 200;
                            cryptoPrices[crypto] += randomChange;
                            cryptoPrices[crypto] = Math.max(cryptoPrices[crypto], 1); // Minimum prijs is 1
                          }
                      
                          saveData();
                          updateCryptoList();
                        }
                      
                        // Event Listeners
                        document.getElementById("buy-button").addEventListener("click", () => handleTransaction("buy"));
                        document.getElementById("sell-button").addEventListener("click", () => handleTransaction("sell"));
                      
                        // Initialisatie
                        simulatePriceFluctuations();
                        updateCryptoList();
                        setInterval(fluctuatePrices, 5000);
                      }
                      

                          